async function loadApp() {
  await import("./app.js");
}

loadApp();
